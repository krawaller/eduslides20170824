let Component = props => {
  return <div>Hello world!</div>
};

ReactDOM.render(
	<Component/>,
	document.getElementById("target")
);